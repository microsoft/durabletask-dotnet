A client implementation for `Microsoft.DurableTask`. This package provides a gRPC `DurableTaskClient` implementation for interacting with a task hub over gRPC.

Commonly used types:
- `GrpcDurableTaskClient`
- `GrpcDurableTaskClientOptions`

For more information, see https://github.com/microsoft/durabletask-dotnet