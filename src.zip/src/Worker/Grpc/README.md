A worker implementation for `Microsoft.DurableTask`. This package provides a gRPC `DurableTaskWorker` implementation for receiving and processing work from a gRPC based task hub.

Commonly used types:
- `GrpcDurableTaskWorker`
- `GrpcDurableTaskWorkerOptions`

For more information, see https://github.com/microsoft/durabletask-dotnet