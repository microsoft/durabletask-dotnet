A client implementation for `Microsoft.DurableTask`. This package includes a `DurableTaskClient` implementation for interacting with a task hub via a `DurableTask.Core.IOrchestrationServiceClient`.

Commonly used types:
- `ShimDurableTaskClient`
- `ShimDurableTaskClientOptions`

For more information, see https://github.com/microsoft/durabletask-dotnet