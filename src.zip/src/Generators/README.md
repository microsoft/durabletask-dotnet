Source generators for `Microsoft.DurableTask`

For more information, see https://github.com/microsoft/durabletask-dotnet